﻿namespace ColorKey
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnColorButton1 = new System.Windows.Forms.Button();
            this.lblColorSpot1 = new System.Windows.Forms.Label();
            this.lblColorSpot2 = new System.Windows.Forms.Label();
            this.btnColorButton2 = new System.Windows.Forms.Button();
            this.lblColorSpot3 = new System.Windows.Forms.Label();
            this.btnColorButton3 = new System.Windows.Forms.Button();
            this.lblColorSpot4 = new System.Windows.Forms.Label();
            this.btnColorButton4 = new System.Windows.Forms.Button();
            this.lblColorSpot5 = new System.Windows.Forms.Label();
            this.btnColorButton5 = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.lblColorSpot6 = new System.Windows.Forms.Label();
            this.btnColorButton6 = new System.Windows.Forms.Button();
            this.lblColorSpot7 = new System.Windows.Forms.Label();
            this.btnColorButton7 = new System.Windows.Forms.Button();
            this.lblColorSpot8 = new System.Windows.Forms.Label();
            this.btnColorButton8 = new System.Windows.Forms.Button();
            this.lblColorSpot9 = new System.Windows.Forms.Label();
            this.btnColorButton9 = new System.Windows.Forms.Button();
            this.lblColorSpot0 = new System.Windows.Forms.Label();
            this.btnColorButton0 = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnColorButton1
            // 
            this.btnColorButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorButton1.Location = new System.Drawing.Point(29, 50);
            this.btnColorButton1.Name = "btnColorButton1";
            this.btnColorButton1.Size = new System.Drawing.Size(102, 78);
            this.btnColorButton1.TabIndex = 0;
            this.btnColorButton1.Text = "1";
            this.btnColorButton1.UseVisualStyleBackColor = true;
            this.btnColorButton1.Click += new System.EventHandler(this.btnColorButton1_Click);
            // 
            // lblColorSpot1
            // 
            this.lblColorSpot1.BackColor = System.Drawing.Color.Black;
            this.lblColorSpot1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColorSpot1.ForeColor = System.Drawing.Color.White;
            this.lblColorSpot1.Location = new System.Drawing.Point(29, 7);
            this.lblColorSpot1.Name = "lblColorSpot1";
            this.lblColorSpot1.Size = new System.Drawing.Size(102, 40);
            this.lblColorSpot1.TabIndex = 1;
            this.lblColorSpot1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblColorSpot1.Click += new System.EventHandler(this.lblColorSpot1_Click);
            // 
            // lblColorSpot2
            // 
            this.lblColorSpot2.BackColor = System.Drawing.Color.Black;
            this.lblColorSpot2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblColorSpot2.ForeColor = System.Drawing.Color.White;
            this.lblColorSpot2.Location = new System.Drawing.Point(138, 7);
            this.lblColorSpot2.Name = "lblColorSpot2";
            this.lblColorSpot2.Size = new System.Drawing.Size(102, 40);
            this.lblColorSpot2.TabIndex = 3;
            this.lblColorSpot2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblColorSpot2.Click += new System.EventHandler(this.lblColorSpot2_Click);
            // 
            // btnColorButton2
            // 
            this.btnColorButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorButton2.Location = new System.Drawing.Point(138, 50);
            this.btnColorButton2.Name = "btnColorButton2";
            this.btnColorButton2.Size = new System.Drawing.Size(102, 78);
            this.btnColorButton2.TabIndex = 2;
            this.btnColorButton2.Text = "2";
            this.btnColorButton2.UseVisualStyleBackColor = true;
            this.btnColorButton2.Click += new System.EventHandler(this.btnColorButton2_Click);
            // 
            // lblColorSpot3
            // 
            this.lblColorSpot3.BackColor = System.Drawing.Color.Black;
            this.lblColorSpot3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblColorSpot3.ForeColor = System.Drawing.Color.White;
            this.lblColorSpot3.Location = new System.Drawing.Point(250, 7);
            this.lblColorSpot3.Name = "lblColorSpot3";
            this.lblColorSpot3.Size = new System.Drawing.Size(98, 40);
            this.lblColorSpot3.TabIndex = 5;
            this.lblColorSpot3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblColorSpot3.Click += new System.EventHandler(this.lblColorSpot3_Click);
            // 
            // btnColorButton3
            // 
            this.btnColorButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorButton3.Location = new System.Drawing.Point(250, 50);
            this.btnColorButton3.Name = "btnColorButton3";
            this.btnColorButton3.Size = new System.Drawing.Size(98, 78);
            this.btnColorButton3.TabIndex = 4;
            this.btnColorButton3.Text = "3";
            this.btnColorButton3.UseVisualStyleBackColor = true;
            this.btnColorButton3.Click += new System.EventHandler(this.btnColorButton3_Click);
            // 
            // lblColorSpot4
            // 
            this.lblColorSpot4.BackColor = System.Drawing.Color.Black;
            this.lblColorSpot4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblColorSpot4.ForeColor = System.Drawing.Color.White;
            this.lblColorSpot4.Location = new System.Drawing.Point(358, 7);
            this.lblColorSpot4.Name = "lblColorSpot4";
            this.lblColorSpot4.Size = new System.Drawing.Size(102, 40);
            this.lblColorSpot4.TabIndex = 7;
            this.lblColorSpot4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblColorSpot4.Click += new System.EventHandler(this.lblColorSpot4_Click);
            // 
            // btnColorButton4
            // 
            this.btnColorButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorButton4.Location = new System.Drawing.Point(360, 50);
            this.btnColorButton4.Name = "btnColorButton4";
            this.btnColorButton4.Size = new System.Drawing.Size(98, 78);
            this.btnColorButton4.TabIndex = 6;
            this.btnColorButton4.Text = "4";
            this.btnColorButton4.UseVisualStyleBackColor = true;
            this.btnColorButton4.Click += new System.EventHandler(this.btnColorButton4_Click);
            // 
            // lblColorSpot5
            // 
            this.lblColorSpot5.BackColor = System.Drawing.Color.Black;
            this.lblColorSpot5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblColorSpot5.ForeColor = System.Drawing.Color.White;
            this.lblColorSpot5.Location = new System.Drawing.Point(472, 7);
            this.lblColorSpot5.Name = "lblColorSpot5";
            this.lblColorSpot5.Size = new System.Drawing.Size(96, 40);
            this.lblColorSpot5.TabIndex = 9;
            this.lblColorSpot5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblColorSpot5.Click += new System.EventHandler(this.lblColorSpot5_Click);
            // 
            // btnColorButton5
            // 
            this.btnColorButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorButton5.Location = new System.Drawing.Point(472, 50);
            this.btnColorButton5.Name = "btnColorButton5";
            this.btnColorButton5.Size = new System.Drawing.Size(96, 78);
            this.btnColorButton5.TabIndex = 8;
            this.btnColorButton5.Text = "5";
            this.btnColorButton5.UseVisualStyleBackColor = true;
            this.btnColorButton5.Click += new System.EventHandler(this.btnColorButton5_Click);
            // 
            // colorDialog1
            // 
            this.colorDialog1.Color = System.Drawing.Color.Red;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(33, 160);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ShowSelectionMargin = true;
            this.richTextBox1.Size = new System.Drawing.Size(435, 217);
            this.richTextBox1.TabIndex = 11;
            this.richTextBox1.Text = "";
            this.richTextBox1.Visible = false;
            // 
            // lblColorSpot6
            // 
            this.lblColorSpot6.BackColor = System.Drawing.Color.Black;
            this.lblColorSpot6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblColorSpot6.ForeColor = System.Drawing.Color.White;
            this.lblColorSpot6.Location = new System.Drawing.Point(578, 7);
            this.lblColorSpot6.Name = "lblColorSpot6";
            this.lblColorSpot6.Size = new System.Drawing.Size(98, 40);
            this.lblColorSpot6.TabIndex = 13;
            this.lblColorSpot6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblColorSpot6.Click += new System.EventHandler(this.lblColorSpot6_Click);
            // 
            // btnColorButton6
            // 
            this.btnColorButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorButton6.Location = new System.Drawing.Point(578, 50);
            this.btnColorButton6.Name = "btnColorButton6";
            this.btnColorButton6.Size = new System.Drawing.Size(98, 78);
            this.btnColorButton6.TabIndex = 12;
            this.btnColorButton6.Text = "6";
            this.btnColorButton6.UseVisualStyleBackColor = true;
            this.btnColorButton6.Click += new System.EventHandler(this.btnColorButton6_Click);
            // 
            // lblColorSpot7
            // 
            this.lblColorSpot7.BackColor = System.Drawing.Color.Black;
            this.lblColorSpot7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblColorSpot7.ForeColor = System.Drawing.Color.White;
            this.lblColorSpot7.Location = new System.Drawing.Point(682, 7);
            this.lblColorSpot7.Name = "lblColorSpot7";
            this.lblColorSpot7.Size = new System.Drawing.Size(102, 39);
            this.lblColorSpot7.TabIndex = 15;
            this.lblColorSpot7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblColorSpot7.Click += new System.EventHandler(this.lblColorSpot7_Click);
            // 
            // btnColorButton7
            // 
            this.btnColorButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorButton7.Location = new System.Drawing.Point(684, 50);
            this.btnColorButton7.Name = "btnColorButton7";
            this.btnColorButton7.Size = new System.Drawing.Size(98, 77);
            this.btnColorButton7.TabIndex = 14;
            this.btnColorButton7.Text = "7";
            this.btnColorButton7.UseVisualStyleBackColor = true;
            this.btnColorButton7.Click += new System.EventHandler(this.btnColorButton7_Click);
            // 
            // lblColorSpot8
            // 
            this.lblColorSpot8.BackColor = System.Drawing.Color.Black;
            this.lblColorSpot8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblColorSpot8.ForeColor = System.Drawing.Color.White;
            this.lblColorSpot8.Location = new System.Drawing.Point(790, 7);
            this.lblColorSpot8.Name = "lblColorSpot8";
            this.lblColorSpot8.Size = new System.Drawing.Size(100, 40);
            this.lblColorSpot8.TabIndex = 17;
            this.lblColorSpot8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblColorSpot8.Click += new System.EventHandler(this.lblColorSpot8_Click);
            // 
            // btnColorButton8
            // 
            this.btnColorButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorButton8.Location = new System.Drawing.Point(788, 50);
            this.btnColorButton8.Name = "btnColorButton8";
            this.btnColorButton8.Size = new System.Drawing.Size(102, 78);
            this.btnColorButton8.TabIndex = 16;
            this.btnColorButton8.Text = "8";
            this.btnColorButton8.UseVisualStyleBackColor = true;
            this.btnColorButton8.Click += new System.EventHandler(this.btnColorButton8_Click);
            // 
            // lblColorSpot9
            // 
            this.lblColorSpot9.BackColor = System.Drawing.Color.Black;
            this.lblColorSpot9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblColorSpot9.ForeColor = System.Drawing.Color.White;
            this.lblColorSpot9.Location = new System.Drawing.Point(896, 7);
            this.lblColorSpot9.Name = "lblColorSpot9";
            this.lblColorSpot9.Size = new System.Drawing.Size(100, 40);
            this.lblColorSpot9.TabIndex = 19;
            this.lblColorSpot9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblColorSpot9.Click += new System.EventHandler(this.lblColorSpot9_Click);
            // 
            // btnColorButton9
            // 
            this.btnColorButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorButton9.Location = new System.Drawing.Point(894, 50);
            this.btnColorButton9.Name = "btnColorButton9";
            this.btnColorButton9.Size = new System.Drawing.Size(102, 78);
            this.btnColorButton9.TabIndex = 18;
            this.btnColorButton9.Text = "9";
            this.btnColorButton9.UseVisualStyleBackColor = true;
            this.btnColorButton9.Click += new System.EventHandler(this.btnColorButton9_Click);
            // 
            // lblColorSpot0
            // 
            this.lblColorSpot0.BackColor = System.Drawing.Color.Black;
            this.lblColorSpot0.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.lblColorSpot0.ForeColor = System.Drawing.Color.White;
            this.lblColorSpot0.Location = new System.Drawing.Point(1002, 7);
            this.lblColorSpot0.Name = "lblColorSpot0";
            this.lblColorSpot0.Size = new System.Drawing.Size(100, 40);
            this.lblColorSpot0.TabIndex = 21;
            this.lblColorSpot0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblColorSpot0.Click += new System.EventHandler(this.lblColorSpot0_Click);
            // 
            // btnColorButton0
            // 
            this.btnColorButton0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnColorButton0.Location = new System.Drawing.Point(1001, 50);
            this.btnColorButton0.Name = "btnColorButton0";
            this.btnColorButton0.Size = new System.Drawing.Size(102, 78);
            this.btnColorButton0.TabIndex = 20;
            this.btnColorButton0.Text = "0";
            this.btnColorButton0.UseVisualStyleBackColor = true;
            this.btnColorButton0.Click += new System.EventHandler(this.btnColorButton0_Click);
            // 
            // btnHelp
            // 
            this.btnHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHelp.Location = new System.Drawing.Point(1148, 12);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(112, 54);
            this.btnHelp.TabIndex = 22;
            this.btnHelp.Text = "HELP";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1315, 288);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.lblColorSpot0);
            this.Controls.Add(this.btnColorButton0);
            this.Controls.Add(this.lblColorSpot9);
            this.Controls.Add(this.btnColorButton9);
            this.Controls.Add(this.lblColorSpot8);
            this.Controls.Add(this.btnColorButton8);
            this.Controls.Add(this.lblColorSpot7);
            this.Controls.Add(this.btnColorButton7);
            this.Controls.Add(this.lblColorSpot6);
            this.Controls.Add(this.btnColorButton6);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.lblColorSpot5);
            this.Controls.Add(this.btnColorButton5);
            this.Controls.Add(this.lblColorSpot4);
            this.Controls.Add(this.btnColorButton4);
            this.Controls.Add(this.lblColorSpot3);
            this.Controls.Add(this.btnColorButton3);
            this.Controls.Add(this.lblColorSpot2);
            this.Controls.Add(this.btnColorButton2);
            this.Controls.Add(this.lblColorSpot1);
            this.Controls.Add(this.btnColorButton1);
            this.Name = "Form1";
            this.Text = "Color Key";
            this.MinimumSizeChanged += new System.EventHandler(this.Form1_MinimumSizeChanged);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnColorButton1;
        private System.Windows.Forms.Label lblColorSpot1;
        private System.Windows.Forms.Label lblColorSpot2;
        private System.Windows.Forms.Button btnColorButton2;
        private System.Windows.Forms.Label lblColorSpot3;
        private System.Windows.Forms.Button btnColorButton3;
        private System.Windows.Forms.Label lblColorSpot4;
        private System.Windows.Forms.Button btnColorButton4;
        private System.Windows.Forms.Label lblColorSpot5;
        private System.Windows.Forms.Button btnColorButton5;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label lblColorSpot6;
        private System.Windows.Forms.Button btnColorButton6;
        private System.Windows.Forms.Label lblColorSpot7;
        private System.Windows.Forms.Button btnColorButton7;
        private System.Windows.Forms.Label lblColorSpot8;
        private System.Windows.Forms.Button btnColorButton8;
        private System.Windows.Forms.Label lblColorSpot9;
        private System.Windows.Forms.Button btnColorButton9;
        private System.Windows.Forms.Label lblColorSpot0;
        private System.Windows.Forms.Button btnColorButton0;
        private System.Windows.Forms.Button btnHelp;
    }
}

