﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ColorKey
{
    public partial class frmHelp : Form
    {
        public frmHelp()
        {
            InitializeComponent();
        }

        private void frmHelp_Load(object sender, EventArgs e)
        {
            rtbHelp.Text = "TO USE:\n\r";
            rtbHelp.Text += "To change color in any of the numbered positions, click a numbered button, select a color from dialog, click ok. ";
            rtbHelp.Text += "The number on the button and the spot above it will change to the color you selected. ";
            rtbHelp.Text += "Open the document you are working on click CRTL-V on any point in the document.  ";
            rtbHelp.Text += "The color that you type will be the color you selected.\n\r";
            rtbHelp.Text += "To change to a color in another position, press CRTL and a number key to select a different color.  ";
            rtbHelp.Text += "For example, if the color currently selected is at 2 and you want to change to 6, press CTRL-6.  Or, you can also ";
            rtbHelp.Text += "click that color spot above the button numbered 6 to select the color.  Again, click on the open document, position the ";
            rtbHelp.Text += "mouse cursor at any point in the document, hit CTRL-V, then what you type will be the color you selected.\n\r\n\r";
            rtbHelp.Text += "If you minimize the window, it will transform into a set of color spots with the numbers in white.  Resize the window, ";
            rtbHelp.Text += "then those white numbers disappear, and the buttons reappear as normal";


        }
    }
}
