﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.Office.Interop.Word;


namespace ColorKey
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            KeyPreview = true;
            this.Activate();
            //The invisible rich text box will have one Zero-Width Space (ZWSP) Character
            //which, upon selecting a color from chart, will be selected with that color,
            //then copied, so that when you open your document and press CTRL-V, that transfers
            //the selected color to your document.
            richTextBox1.Text = "​";
            ToolTip ttReminder = new ToolTip();
            ttReminder.SetToolTip(this, "REMEMBER - after selecting a color, when you open your document hit CTRL-V to transfer the color to document.");
          }

    

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
          //THE HOT KEY FUNCTIONALITY (press CTRL with a number)
          if (e.Control)
            {
                switch(e.KeyCode.ToString())
                {
                    case "D1":
                        btnColorButton1.Select();
                        CopyColor(lblColorSpot1.BackColor);
                        break;
                    case "D2":
                        btnColorButton2.Select();
                        CopyColor(lblColorSpot2.BackColor);
                        break;
                    case "D3":
                        btnColorButton3.Select();
                        CopyColor(lblColorSpot3.BackColor);
                        break;
                    case "D4":
                        btnColorButton4.Select();
                        CopyColor(lblColorSpot4.BackColor);
                        break;
                    case "D5":
                        btnColorButton5.Select();
                        CopyColor(lblColorSpot5.BackColor);
                        break;
                    case "D6":
                        btnColorButton6.Select();
                        CopyColor(lblColorSpot6.BackColor);
                        break;
                    case "D7":
                        btnColorButton7.Select();
                        CopyColor(lblColorSpot7.BackColor);
                        break;
                    case "D8":
                        btnColorButton8.Select();
                        CopyColor(lblColorSpot8.BackColor);
                        break;
                    case "D9":
                        btnColorButton9.Select();
                        CopyColor(lblColorSpot9.BackColor);
                        break;
                    case "D0":
                        btnColorButton0.Select();
                        CopyColor(lblColorSpot0.BackColor);
                        break;
                }
            }
 
        }

        //THE BELOW CLICK BUTTON FUNCTIONS CHANGE THE COLOR OF THE COLOR KEY POSITIONS
        private void btnColorButton1_Click(object sender, EventArgs e)
        {
            OpenColorChart(lblColorSpot1, btnColorButton1);
            CopyColor(lblColorSpot1.BackColor);
        }
        private void btnColorButton2_Click(object sender, EventArgs e)
        {
            OpenColorChart(lblColorSpot2, btnColorButton2);
            CopyColor(lblColorSpot2.BackColor);
        }

        private void btnColorButton3_Click(object sender, EventArgs e)
        {
            OpenColorChart(lblColorSpot3, btnColorButton3);
            CopyColor(lblColorSpot3.BackColor);
        }
        private void btnColorButton4_Click(object sender, EventArgs e)
        {
            OpenColorChart(lblColorSpot4, btnColorButton4);
            CopyColor(lblColorSpot4.BackColor);
        }

        private void btnColorButton5_Click(object sender, EventArgs e)
        {
            OpenColorChart(lblColorSpot5, btnColorButton5);
            CopyColor(lblColorSpot5.BackColor);
        }

        private void btnColorButton6_Click(object sender, EventArgs e)
        {
            OpenColorChart(lblColorSpot6, btnColorButton6);
            CopyColor(lblColorSpot6.BackColor);
        }
        private void btnColorButton7_Click(object sender, EventArgs e)
        {
            OpenColorChart(lblColorSpot7, btnColorButton7);
            CopyColor(lblColorSpot7.BackColor);
        }
        private void btnColorButton8_Click(object sender, EventArgs e)
        {
            OpenColorChart(lblColorSpot8, btnColorButton8);
            CopyColor(lblColorSpot8.BackColor);
        }
        private void btnColorButton9_Click(object sender, EventArgs e)
        {
            OpenColorChart(lblColorSpot9, btnColorButton9);
            CopyColor(lblColorSpot9.BackColor);
        }
        private void btnColorButton0_Click(object sender, EventArgs e)
        {
            OpenColorChart(lblColorSpot0, btnColorButton0);
            CopyColor(lblColorSpot0.BackColor);
        }


        //THIS FUNCTION OPENS THE COLOR DIALOG AT CLICK OF ONE OF THE BUTTONS
        private void OpenColorChart(Label lblColorSpot, Button btnColorButton)
        {
          while (colorDialog1.ShowDialog() != DialogResult.OK)
            {
                if (colorDialog1.ShowDialog() == DialogResult.Cancel) return;
               System.Windows.Forms.Application.DoEvents();
            }
            lblColorSpot.BackColor = colorDialog1.Color;
            btnColorButton.ForeColor = colorDialog1.Color;
        }

        private void CopyColor(Color changeColor)
        {

            //THIS IS THE TRICK AS TO WHERE THE COLOR COMES FROM 
            //BEFORE TRANSFERRING TO DOCUMENT
            richTextBox1.SelectAll();
            richTextBox1.SelectionColor = changeColor;
            richTextBox1.Copy();
        }


        //YOU CAN ALSO CHANGE YOUR COLOR BY CLICKING ON A SPOT ABOVE A BUTTON
        private void lblColorSpot1_Click(object sender, EventArgs e)
        {
            btnColorButton1.Select();
            CopyColor(lblColorSpot1.BackColor);
        }

        private void lblColorSpot2_Click(object sender, EventArgs e)
        {
            btnColorButton2.Select();
            CopyColor(lblColorSpot2.BackColor);
        }

        private void lblColorSpot3_Click(object sender, EventArgs e)
        {
            btnColorButton3.Select();
            CopyColor(lblColorSpot3.BackColor);
        }

        private void lblColorSpot4_Click(object sender, EventArgs e)
        {
            btnColorButton4.Select();
            CopyColor(lblColorSpot4.BackColor);
        }

        private void lblColorSpot5_Click(object sender, EventArgs e)
        {
            btnColorButton5.Select();
            CopyColor(lblColorSpot5.BackColor);
        }

        private void lblColorSpot6_Click(object sender, EventArgs e)
        {
            btnColorButton6.Select();
            CopyColor(lblColorSpot6.BackColor);
        }

        private void lblColorSpot7_Click(object sender, EventArgs e)
        {
            btnColorButton7.Select();
            CopyColor(lblColorSpot7.BackColor);
        }

        private void lblColorSpot8_Click(object sender, EventArgs e)
        {
            btnColorButton8.Select();
            CopyColor(lblColorSpot8.BackColor);
        }

        private void lblColorSpot9_Click(object sender, EventArgs e)
        {
            btnColorButton9.Select();
            CopyColor(lblColorSpot9.BackColor);
        }

        private void lblColorSpot0_Click(object sender, EventArgs e)
        {
            btnColorButton0.Select();
            CopyColor(lblColorSpot0.BackColor);
        }

        //MINIMIZE THE FORM SO THAT ALL THAT SHOWS ARE THE NUMBERED COLOR SPOTS
        private void Form1_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                Size winSize = new Size(800, 70);
                this.Size = winSize;
                int colorCount = 9;
                foreach (Control ctl in this.Controls)
                {
                    if (ctl.Name.Contains("ColorSpot") && ctl.Name.Contains(colorCount.ToString()))
                    {
                        ctl.Text = colorCount.ToString();
                        --colorCount;
                    }
                }
                this.lblColorSpot0.Text = "0";
            }
         
            if (this.Height>240)
            {

                int colorCount = 9;
                foreach (Control ctl in this.Controls)
                {
                    if (ctl.Name.Contains("ColorSpot") && ctl.Name.Contains(colorCount.ToString()))
                    {
                        ctl.Text = "";
                        --colorCount;
                    }
                }
                this.lblColorSpot0.Text = "";
            }
         
        }
        //RESIZE TO REMOVE THE NUMBERS ON SPOTS AND REVEAL THE BUTTONS
        private void Form1_MinimumSizeChanged(object sender, EventArgs e)
        {
            int colorCount = 9;
            foreach (Control ctl in this.Controls)
            {
                if (ctl.Name.Contains("ColorSpot") && ctl.Name.Contains(colorCount.ToString()))
                {
                    ctl.Text = "";
                    --colorCount;
                }
            }
            this.lblColorSpot0.Text = "";
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            frmHelp theHelp = new frmHelp();
            theHelp.Show();
        }
    }
}
